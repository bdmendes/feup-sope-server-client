extern int delay;
